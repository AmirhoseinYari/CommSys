function x = SourceEncode(b)



end