clc
clear
close all

n = 100;
x = InformationSource(n)

b = SourceEncoder(n,x)
